A lightweight command-line audio visualizer.
This program is in "Vaguely Beta", and is subject to change at any time.

For usage rights, please refer to LICENSE.txt


DID YOU FORGET WHAT AN .ISS FILE IS?
It's an inno installer setup file. Edit it, and you'll need this: http://www.jrsoftware.org/isdl.php